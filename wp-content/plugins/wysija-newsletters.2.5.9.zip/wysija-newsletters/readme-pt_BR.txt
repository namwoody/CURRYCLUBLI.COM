=== Wysija Newsletters ===
Contributors: wysija
Tags: newsletter, newsletters, manager newsletter, newsletter signup, newsletter widget, subscribers, post notification, email subscription, email alerts, automatic newsletter, auto newsletter, autoresponder, autoresponders, follow up, email marketing, email, emailing, subscription
Requires at least: 3.0
Tested up to: 3.5
Stable tag: trunk

Send your posts and newsletters from WordPress easily, and beautifully.


== Description ==

Drag and drop your articles, images, social bookmarks and dividers in your newsletter. Pick one of 20 themes. Change fonts and colors on the fly. Manage your lists and subscription forms with a few clicks. Configuration is dummy proof. And if you're lost, [we're here](http://support.mailpoet.com/) to help. Sending newsletters from WordPress is finally fun.


= One minute video demo =

http://vimeo.com/35054446


== Translation Credits ==

Translation to pt-BR by DJIO*

Language: Brazilian Portuguese
Translator Name: Dionizio Bonfim Bach
Translator Website: http://www.djio.com.br
Translator E-mail: translations@.djio.com.br

* Based on previous collaboration of some contributors, according to the oficial website:
- Alvaro
- Raphael Suzuki


== Installation Instructions ==

Place the enclosed files in the plugin folder respecting the file structure as shown below.

/languages/
	wysija-newsletters-pt_BR.mo
	wysija-newsletters-pt_BR.po


== Disclaimer ==

The files provided on this folder and on enclosed folders (Software) are provided "as is". Use at your own risk.